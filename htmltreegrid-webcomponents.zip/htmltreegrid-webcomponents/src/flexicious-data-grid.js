(function () {
    var
        settingsParser = new HotTableUtils.SettingsParser(),
        lastSelectedCellMeta;
    
    
    
    var behaviors = {};

    flexiciousNmsp.pro.forEach(function(method) {
        PublicMethodsBehavior[method] = function() {
        return this.hot[method].apply(this.hot, arguments);
        };
    });


    Polymer({
        is: 'flexicious-data-grid',
        properties: settingsParser.getHotTableProperties(),

        behaviors: [
            behaviors
        ],

        /**
         * @property hot
         * @type Handsontable
         * @default null
         */
        hot: null,

        /**
         * On create element but not attached to DOM
         */
        created: function () {
        },

        /**
         * On attached element to DOM
         */
        attached: function () {

        },

        /**
         * Try to destroy handsontable instance if hadn't been destroyed
         */
        detached: function () {

        },

        /**
         * Register hooks
         */
        registerHooks: function () {

        },


        attributeChanged: function () {
            this._onChanged();
        },

        _onChanged: function () {
            var settings;

            settings = settingsParser.parse(this);
            this.hot.updateSettings(settings);
        }
    });
} ());
