(function() {
  var
    settingsParser = new HotTableUtils.SettingsParser();

  Polymer({
    is: 'flexicious-data-grid-column',
    properties: settingsParser.getHotColumnProperties(),

    attached: function() {
      this.registerRenderer(findRenderer(this));
      this.registerEditor(findEditor(this));

      if (this.parentNode && this.parentNode.onMutation) {
        this.parentNode.onMutation();
      }
    },

    attributeChanged: function() {
      this._onChanged();
    },

    _onChanged: function() {
      if (this.parentNode) {
        this.parentNode.onMutation();
      }
    }
  });
}());
